import { useState, useEffect } from 'react';
import StatsCard from './components/StatsCard';
import DailyBreakdown from './components/DailyBreakdown';
import {
  parsePunches,
  computeDailySummary,
  calculateOverallStats,
  formatHoursMinutesSeconds,
  formatHoursMinutes,
  DaySummary,
} from './utils/timeParser';

// Local storage keys
const STORAGE_KEYS = {
  RAW_TEXT: 'workHoursCalc_rawText',
  GRID_VIEW: 'workHoursCalc_gridView',
};

function App() {
  // Load initial state from localStorage
  const [rawText, setRawText] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.RAW_TEXT);
    return saved || '';
  });
  
  const [summaries, setSummaries] = useState<DaySummary[]>([]);
  
  const [gridView, setGridView] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.GRID_VIEW);
    return saved === 'true';
  });
  
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [soundPlayed, setSoundPlayed] = useState(false);

  // Save rawText to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.RAW_TEXT, rawText);
  }, [rawText]);

  // Save gridView to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.GRID_VIEW, gridView.toString());
  }, [gridView]);

  // Auto-parse on mount if there's saved data
  useEffect(() => {
    if (rawText.trim()) {
      handleParse();
    }
  }, []); // Run only once on mount

  // Auto-refresh every 1 second if there's data (for live "Now" updates with seconds)
  useEffect(() => {
    if (summaries.length > 0 && rawText.trim()) {
      const interval = setInterval(() => {
        handleParse();
      }, 1000); // Refresh every 1 second for live seconds updates
      return () => clearInterval(interval);
    }
  }, [summaries.length, rawText]);

  // Check for goal completion and play sound
  useEffect(() => {
    const todaySummary = summaries.find(s => s.isToday && s.currentlyWorking);
    if (todaySummary && todaySummary.remaining <= 0 && !todaySummary.isOvertime && !soundPlayed) {
      playNotificationSound();
      setSoundPlayed(true);
    }
    // Reset sound flag if remaining time goes back above 0
    if (todaySummary && todaySummary.remaining > 0) {
      setSoundPlayed(false);
    }
  }, [summaries, soundPlayed]);

  const playNotificationSound = () => {
    // Create a pleasant notification sound using Web Audio API
    const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioContext.createOscillator();
    const gainNode = audioContext.createGain();
    
    oscillator.connect(gainNode);
    gainNode.connect(audioContext.destination);
    
    oscillator.frequency.value = 800;
    oscillator.type = 'sine';
    
    gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
    
    oscillator.start(audioContext.currentTime);
    oscillator.stop(audioContext.currentTime + 0.5);
    
    // Play a second tone
    setTimeout(() => {
      const osc2 = audioContext.createOscillator();
      const gain2 = audioContext.createGain();
      osc2.connect(gain2);
      gain2.connect(audioContext.destination);
      osc2.frequency.value = 1000;
      osc2.type = 'sine';
      gain2.gain.setValueAtTime(0.3, audioContext.currentTime);
      gain2.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      osc2.start(audioContext.currentTime);
      osc2.stop(audioContext.currentTime + 0.5);
    }, 200);
  };

  const handleParse = () => {
    try {
      if (!rawText.trim()) {
        setError('Please paste some log data first.');
        setSummaries([]);
        return;
      }

      const records = parsePunches(rawText);
      if (!records.length) {
        setError('No valid IN/OUT records found. Please check the format. Expected format: Name on one line, IN/OUT on next line, Date-Time (DD-MM-YYYY HH:MM:SS) on next line.');
        setSummaries([]);
        return;
      }

      const dailySummaries = computeDailySummary(records, false); // Always show all days
      setSummaries(dailySummaries);
      setError(null);
      
      // Update timestamp
      const now = new Date();
      setLastUpdated(
        `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}:${String(now.getSeconds()).padStart(2, '0')}`
      );
    } catch (e) {
      console.error('Parse error:', e);
      setError(`Error parsing logs: ${e instanceof Error ? e.message : 'Unknown error'}`);
      setSummaries([]);
    }
  };

  const handleClear = () => {
    setRawText('');
    setSummaries([]);
    setError(null);
    localStorage.removeItem(STORAGE_KEYS.RAW_TEXT);
  };

  const stats = summaries.length > 0 ? calculateOverallStats(summaries) : null;

  const exampleText = `Dheeraj Deepak Mathur
IN
19-01-2026 10:54:14
Approved
1 h
0
·

Dheeraj Deepak Mathur
OUT
19-01-2026 15:31:15
Approved
2 h
0
·

Dheeraj Deepak Mathur
IN
19-01-2026 16:10:48
Approved
1 h
0
·`;

  return (
    <div className="min-h-screen bg-slate-950 py-6 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header - More Compact */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-slate-100 mb-2">
            ⏱️ Work Hours Calculator
          </h1>
          <p className="text-slate-400 text-sm max-w-2xl mx-auto">
            Parse your logs instantly. Calculate working hours, breaks, and detect anomalies.
          </p>
        </div>

        {/* Input Section - More Compact */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl mb-6">
          <div className="flex items-center justify-between mb-2">
            <label className="block text-xs font-medium text-slate-400">
              Paste logs here...
            </label>
            {rawText && (
              <span className="text-xs text-green-400 flex items-center gap-1">
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                Saved
              </span>
            )}
          </div>
          <textarea
            className="w-full h-32 bg-slate-950 border border-slate-700 rounded-lg p-3 text-slate-100 font-mono text-xs focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent resize-none"
            placeholder={exampleText}
            value={rawText}
            onChange={(e) => setRawText(e.target.value)}
          />
          <div className="flex items-center gap-3 mt-3">
            <button
              onClick={handleParse}
              className="btn-primary-compact"
            >
              Parse Logs
            </button>
            <button
              onClick={handleClear}
              className="btn-secondary-compact"
            >
              Clear
            </button>
            <div className="ml-auto flex items-center gap-2 text-xs text-slate-400">
              <svg className="w-4 h-4 text-primary-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {summaries.length > 0 ? `${summaries.length} ${summaries.length === 1 ? 'entry' : 'entries'}` : 'Ready'}
            </div>
          </div>
        </div>

        {/* Error Message - More Compact */}
        {error && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-3 mb-6">
            <div className="flex items-center gap-2">
              <svg className="w-4 h-4 text-red-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <span className="text-red-400 text-xs">{error}</span>
            </div>
          </div>
        )}

        {/* Stats Section - More Compact */}
        {stats && (
          <>
            {/* Overall Dashboard */}
            <div className="bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700 rounded-xl p-6 shadow-2xl mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-slate-100 flex items-center gap-2">
                  <span className="text-3xl">📊</span>
                  Overall Dashboard
                </h2>
                {stats.isCurrentlyWorking && (
                  <div className="flex items-center gap-2 bg-green-500/10 border border-green-500/30 px-3 py-1 rounded-full">
                    <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></span>
                    <span className="text-xs text-green-400 font-semibold">Currently Working</span>
                  </div>
                )}
              </div>
              
              {/* Main Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                {/* Total Hours Worked */}
                <div className="bg-slate-950/50 rounded-lg p-4 border border-slate-700">
                  <p className="text-slate-400 text-xs mb-1">⏱️ Total Hours Worked</p>
                  <p className="text-3xl font-bold text-primary-400">{stats.totalFormatted}</p>
                  <p className="text-xs text-slate-500 mt-1">{stats.totalHours.toFixed(2)} hours</p>
                  {stats.isCurrentlyWorking && stats.todayRemaining > 0 && (
                    <p className="text-xs text-green-400 mt-1">
                      → {stats.projectedTotalFormatted} (projected)
                    </p>
                  )}
                </div>
                
                {/* Expected Hours */}
                <div className="bg-slate-950/50 rounded-lg p-4 border border-slate-700">
                  <p className="text-slate-400 text-xs mb-1">🎯 Expected Hours</p>
                  <p className="text-3xl font-bold text-slate-300">{stats.expectedFormatted}</p>
                  <p className="text-xs text-slate-500 mt-1">{stats.daysTracked} days × 8h</p>
                </div>
                
                {/* Difference (Overtime/Remaining) */}
                <div className={`bg-slate-950/50 rounded-lg p-4 border ${
                  stats.isOvertime ? 'border-amber-500/30' : 'border-blue-500/30'
                }`}>
                  <p className="text-slate-400 text-xs mb-1">
                    {stats.isOvertime ? '🔥 Total Overtime' : '⏳ Total Remaining'}
                  </p>
                  <p className={`text-3xl font-bold ${
                    stats.isOvertime ? 'text-amber-400' : 'text-blue-400'
                  }`}>
                    {stats.differenceFormatted}
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {stats.isOvertime ? 'Above target' : 'Below target'}
                  </p>
                  {stats.isCurrentlyWorking && stats.todayRemaining > 0 && !stats.isOvertime && (
                    <p className="text-xs text-green-400 mt-1">
                      (After today: {stats.adjustedRemainingFormatted})
                    </p>
                  )}
                </div>
                
                {/* Average Per Day */}
                <div className="bg-slate-950/50 rounded-lg p-4 border border-slate-700">
                  <p className="text-slate-400 text-xs mb-1">📊 Average/Day</p>
                  <p className="text-3xl font-bold text-green-400">{stats.averageHoursPerDayFormatted}</p>
                  <p className="text-xs text-slate-500 mt-1">{stats.averageHoursPerDay.toFixed(2)} hours</p>
                </div>
              </div>
              
              {/* Today's Progress Banner (if currently working) */}
              {stats.isCurrentlyWorking && stats.todayRemaining > 0 && (
                <div className="bg-gradient-to-r from-green-500/10 to-blue-500/10 border border-green-500/30 rounded-lg p-4 mb-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-sm font-semibold text-green-400 mb-1 flex items-center gap-2">
                        <span>🎯</span> Today's Goal Progress
                      </h3>
                      <p className="text-xs text-slate-400">
                        You're currently working. Complete today's goal to reduce overall remaining hours.
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-slate-400 mb-1">Remaining Today</p>
                      <p className="text-2xl font-bold text-green-400">{stats.todayRemainingFormatted}</p>
                    </div>
                  </div>
                </div>
              )}
              
              {/* Detailed Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Days Breakdown */}
                <div className="bg-slate-950/30 rounded-lg p-4 border border-slate-700/50">
                  <h3 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
                    <span>📅</span> Days Breakdown
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-400">Total Days Tracked</span>
                      <span className="text-sm font-bold text-slate-100">{stats.daysTracked}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-green-400">✓ Goal Completed</span>
                      <span className="text-sm font-bold text-green-400">{stats.completedDays}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-amber-400">🔥 Overtime Days</span>
                      <span className="text-sm font-bold text-amber-400">{stats.overtimeDays}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-blue-400">⏳ Remaining Days</span>
                      <span className="text-sm font-bold text-blue-400">{stats.remainingDays}</span>
                    </div>
                  </div>
                </div>
                
                {/* Overtime Summary */}
                <div className="bg-amber-500/5 rounded-lg p-4 border border-amber-500/20">
                  <h3 className="text-sm font-semibold text-amber-400 mb-3 flex items-center gap-2">
                    <span>🔥</span> Overtime Summary
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-400">Total Overtime</span>
                      <span className="text-sm font-bold text-amber-400">{stats.totalOvertimeFormatted}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-400">Days with Overtime</span>
                      <span className="text-sm font-bold text-amber-400">{stats.overtimeDays}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-400">Avg Overtime/Day</span>
                      <span className="text-sm font-bold text-amber-400">
                        {stats.overtimeDays > 0 
                          ? formatHoursMinutes(stats.totalOvertime / stats.overtimeDays)
                          : '0h'}
                      </span>
                    </div>
                  </div>
                </div>
                
                {/* Remaining Summary */}
                <div className="bg-blue-500/5 rounded-lg p-4 border border-blue-500/20">
                  <h3 className="text-sm font-semibold text-blue-400 mb-3 flex items-center gap-2">
                    <span>⏳</span> Remaining Summary
                    {stats.isCurrentlyWorking && stats.todayRemaining > 0 && (
                      <span className="text-xs text-slate-500">(excl. today)</span>
                    )}
                  </h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-400">Total Remaining</span>
                      <span className="text-sm font-bold text-blue-400">
                        {stats.isCurrentlyWorking && stats.todayRemaining > 0 
                          ? stats.adjustedRemainingFormatted 
                          : stats.totalRemainingFormatted}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-400">Days with Remaining</span>
                      <span className="text-sm font-bold text-blue-400">
                        {stats.isCurrentlyWorking && stats.todayRemaining > 0 
                          ? stats.remainingDays - 1 
                          : stats.remainingDays}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-slate-400">Avg Remaining/Day</span>
                      <span className="text-sm font-bold text-blue-400">
                        {(() => {
                          const daysCount = stats.isCurrentlyWorking && stats.todayRemaining > 0 
                            ? stats.remainingDays - 1 
                            : stats.remainingDays;
                          const totalRem = stats.isCurrentlyWorking && stats.todayRemaining > 0 
                            ? stats.adjustedRemaining 
                            : stats.totalRemaining;
                          return daysCount > 0 
                            ? formatHoursMinutes(totalRem / daysCount)
                            : '0h';
                        })()}
                      </span>
                    </div>
                    {stats.isCurrentlyWorking && stats.todayRemaining > 0 && (
                      <div className="pt-2 mt-2 border-t border-blue-500/20">
                        <div className="flex justify-between items-center">
                          <span className="text-xs text-green-400">+ Today's Remaining</span>
                          <span className="text-xs font-semibold text-green-400">{stats.todayRemainingFormatted}</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
            
            {/* Quick Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <StatsCard
                label="Total Hours"
                value={stats.totalFormatted}
                icon="⏱️"
                color="primary"
              />
              <StatsCard
                label="Days Tracked"
                value={stats.daysTracked.toString()}
                icon="📅"
                color="secondary"
              />
              <div className="stat-card-compact">
                <p className="text-slate-400 text-xs font-medium mb-2">Actions</p>
                <div className="flex gap-2 mb-2">
                  <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-medium py-2 px-2 rounded-lg transition-all">
                    📊 Export
                  </button>
                  <button className="flex-1 bg-slate-800 hover:bg-slate-700 text-slate-100 text-xs font-medium py-2 px-2 rounded-lg transition-all">
                    📋 Copy
                  </button>
                </div>
                <button 
                  onClick={playNotificationSound}
                  className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white text-xs font-medium py-2 px-2 rounded-lg transition-all shadow-lg shadow-green-500/30"
                >
                  🔔 Test Notification Sound
                </button>
                {lastUpdated && (
                  <p className="text-xs text-slate-500 mt-2">
                    Updated: {lastUpdated}
                  </p>
                )}
              </div>
            </div>

            {/* Daily Breakdown Section */}
            <div className="mb-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-slate-100">Daily Breakdown</h2>
                <div className="flex gap-2">
                  <button
                    onClick={() => setGridView(!gridView)}
                    className={`px-3 py-2 rounded-lg font-medium text-xs transition-all ${
                      gridView
                        ? 'bg-primary-500 text-white shadow-lg shadow-primary-500/30'
                        : 'bg-slate-800 text-slate-300 border border-slate-700'
                    }`}
                  >
                    {gridView ? '📊 Grid View' : '📋 List View'}
                  </button>
                </div>
              </div>
            </div>

            {/* Daily Breakdown List/Grid */}
            <div className={gridView ? 'grid grid-cols-1 md:grid-cols-2 gap-4' : 'space-y-4'}>
              {summaries.map((summary) => (
                <DailyBreakdown key={summary.date} summary={summary} compact={gridView} />
              ))}
            </div>
          </>
        )}

        {/* Empty State */}
        {!stats && !error && (
          <div className="text-center py-16">
            <div className="text-6xl mb-4">📊</div>
            <h3 className="text-xl font-semibold text-slate-300 mb-2">
              No data yet
            </h3>
            <p className="text-slate-500">
              Paste your IN/OUT logs above and click "Parse Logs" to get started.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;
